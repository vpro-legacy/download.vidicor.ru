
function MakeTitleHtml(name, align)
{
  return "<P align=" + align + ">" + name + "</P>";
}

function MakeButtonHtml(addr)
{
  return "<BUTTON onClick=\"window.open(\'http://" + addr + "/ctl/\', \'_blank\');\">����������</BUTTON>";
}

function FillServersTable(table)
{
  var cntT = transName.length;
  var cntR = recvName.length;
  var cntMax = cntT;
  if (cntMax < cntR) cntMax = cntR;
  for (var i = 0; i < cntMax; i++)
  {
    var row = table.insertRow();
    var cellTN = row.insertCell();
    var cellTB = row.insertCell();
    var cellA  = row.insertCell();
    var cellRB = row.insertCell();
    var cellRN = row.insertCell();
    cellTB.width = '1';
    cellA.width  = '105';
    cellRB.width = '1';
    if (i < transName.length)
    {
      cellTN.innerHTML = MakeTitleHtml(transName[i], "right");
      cellTB.innerHTML = MakeButtonHtml(transAddr[i]);
    }
    cellA.innerHTML = "<CENTER><IMG src='files/darrow.gif'></CENTER>";
    if (i < recvName.length)
    {
      cellRN.innerHTML = MakeTitleHtml(recvName[i], "left");
      cellRB.innerHTML = MakeButtonHtml(recvAddr[i]);
    }
  }
}

function OpenConfig()
{
  window.open("-config-.inf");
}

function Reload()
{
  document.location.reload();
}

<?php
//����� ��������� ���������������
$URL = "rmxvp://195.19.132.60/capture/LiveCam";
//������ �����
$H = "576px";
//������ �����
$W = "720px";

$agent =  $_SERVER['HTTP_USER_AGENT'];


function Opera()
{
?>	
<OBJECT type="application/x-vidicor-plugin" pluginspage='plugin.msi'
    WIDTH="<?php global $W; echo $W ?>" HEIGHT="<?php global $H; echo $H ?>" 
    URL="<?php global $URL; echo $URL ?>"    
    EnableLimit="0"
    ShowControls="1"
    MulticastTimeout="5">
</OBJECT>
<?php	
}

function  IE() 
{
?>

<OBJECT CLASSID="CLSID:6540685D-ABC2-4dfb-BC97-D71C5951B226" codebase='plugin.msi'
  WIDTH="<?php global $W; echo $W ?>" HEIGHT="<?php global $H; echo $H ?>" >
  <PARAM NAME="URL" VALUE="<?php global $URL; echo $URL ?>">
  <PARAM NAME="EnableLimit" VALUE="0">
  <PARAM NAME="ShowControls" VALUE="1">
  <PARAM NAME="MulticastTimeout" VALUE="5">  
</object>

<?php
}

function Gecko()
{
?>
<EMBED type="application/x-vidicor-plugin" pluginspage='plugin.msi'
    WIDTH="<?php global $W; echo $W ?>" HEIGHT="<?php global $H; echo $H ?>"  
    URL="<?php global $URL; echo $URL ?>"    
    EnableLimit="0"
    ShowControls="1"
    MulticastTimeout="5">
</EMBED>

<?php
}

if (stripos($agent, "gecko") > -1) Gecko();
else
if (stripos($agent, "opera") > -1) Opera();
else IE();
?> 

